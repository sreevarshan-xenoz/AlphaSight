"""
NIFTY 50 ML Pipeline - A CPU-optimized machine learning pipeline for predicting NIFTY 50 index movements.
"""

__version__ = "0.1.0"
__author__ = "NIFTY ML Pipeline Team"